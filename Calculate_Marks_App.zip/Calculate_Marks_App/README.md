# Calculate_Marks
Multi Screen transferring data
> **1.1-->Starting Interface**


![Screenshot_20211106_232856_com raushan interface1](https://user-images.githubusercontent.com/76262545/140619412-02f424c1-2bb8-4e18-9e96-c62c8af3f69f.jpg)

> ###1.2--> **After Clicking on **Semester Marks** and Entering the marks**

![Screenshot_20211106_232930_com raushan interface1](https://user-images.githubusercontent.com/76262545/140619423-014f2f5a-16de-4183-bc5c-a53b78f1c9df.jpg)

> ###1.3--> After Clicking  on **"CALCULATE YOUR MARKS"**, the final result output screen is visible

![Screenshot_20211106_232938_com raushan interface1](https://user-images.githubusercontent.com/76262545/140619437-66627de6-1a81-4f48-8c3d-5ed235fa6a7c.jpg)
)


> Pic 2.1---> Click on **" YEAR-WISE MARKS"**
![Screenshot_20211106_232856_com raushan interface1](https://user-images.githubusercontent.com/76262545/140619412-02f424c1-2bb8-4e18-9e96-c62c8af3f69f.jpg)


 >Pic 2.2---> Enter the **year-wise marks** and click on **"Calculate Marks"**.

![Screenshot_20211106_232956_com raushan interface1](https://user-images.githubusercontent.com/76262545/140619455-567c5d57-159c-4333-8c0d-f4e466a6f41b.jpg)


> Pic 2.3--->**and the **final** output UI**
![Screenshot_20211106_233005_com raushan interface1](https://user-images.githubusercontent.com/76262545/140619444-a44fee21-d071-4d1e-9f79-d27c56238f4a.jpg)

>After Clicking on Grade--->Percentage
![Screenshot_20211106_233024_com raushan interface1](https://user-images.githubusercontent.com/76262545/140619449-8d0efb29-661f-4cfd-a999-a89c74b2c6cd.jpg)

>After Clicking on Percentage---> Grade
![Screenshot_20211106_233038_com raushan interface1](https://user-images.githubusercontent.com/76262545/140619453-d58f3c74-7bd3-42bc-bfaf-afe29cdfff7e.jpg)


